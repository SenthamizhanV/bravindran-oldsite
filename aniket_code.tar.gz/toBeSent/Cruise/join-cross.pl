#!/usr/bin/perl
#


#usage: ./perl join-cross

$d = ".dat";
$cattrain = "folded/cattrain";
$realtrain = "folded/realtrain";
$cattest = "folded/cattest";
$realtest = "folded/realtest";


for($i=1; $i<=5; $i++)
{
	$tmp="perl join-train.pl ".$cattrain.$i.$d." ".$realtrain.$i.$d;
	system("$tmp");
	$tmp = "perl join-test.pl ".$cattrain.$i.$d." ".$cattest.$i.$d." ".$realtest.$i.$d. " pred".$i;
	system("$tmp");
}

