#!/usr/bin/perl
#
# USAGE: perl join-test <cat-train-filename> <cat-test-filename> <real-test-filename> <classification-output-file>
#this file retrains based on cat
#assumes that rest of the model is present in /model/

$cattrainer = $ARGV[0];
$cattester = $ARGV[1];
$realtester = $ARGV[2];
$predfile = $ARGV[3];


#generate filedsc.dat
#
open(OUF, ">./filedsc.dat");
open (INF, "dsctemplate.dat");
print OUF "\"$cattrainer\"\n";
while($line = <INF>)
{
	print OUF "$line";
}

close(OUF);
close(INF);




#generate input file input1 - corresponding to training file

$tmpClassified = "temp_classified.dat";
open(OUF,">./input1");
open(INF,"./inptemplate");
$num=0;
while($line = <INF>)
{
	$num++;
	if($num == 21)
	{
		print OUF "\"$cattester\"\n";
	}
	elsif($num == 22)
	{
		print OUF "$tmpClassified\n";
	}
	else
	{
		print OUF "$line";
	}
}
close(OUF);
close(INF);




#execute cruise
system("./cruise < input1");


#check in tempClassified File 
#if node is in tempManage , check if svm is required
#if yes then run svm-predict else return class
open(INF, "$tmpClassified");
$line = <INF>; #skipping the first line
open (OUF, ">$predfile");
open(REAL, "$realtester");
@ep = ([0,0,0],[0,0,0],[0,0,0]);
while($line = <INF>)
{

	$svmdata = <REAL>;
	if($line =~ /[ ]*([0-9]+)[ ]+([0-9]+) ([0-9]) ([0-9])/)
	{
		open(TMP, "./model/tempManage.dat");
		
		while($tmpline = <TMP>)
		{
			@info = split(/\:/,$tmpline);
		
#			print "$info[0] $2 $info[2]\n";
			if($info[0] == $2)
			{
				if($info[2] eq 'y')
				{
					open(TMPTEST, ">./temp_svm_test.dat");
					print TMPTEST $svmdata;
					close(TMPTEST);
					$model = "./model/svm" . $info[0] . ".dat";
					system("./svm-scale -l 0 -u 1 ./temp_svm_test.dat > ./scaled_svm_test.dat");
					system("./svm-predict ./scaled_svm_test.dat $model ./temp_test_out");
					open(TMPTEST, "./temp_test_out");
					$tmpline2 = <TMPTEST>;
					print OUF "$1:$3:$tmpline2";
					$ep[$3][$tmpline2]++;
					close(TMPTEST);
				}
				else
				{
					print OUF "$1:$3:$info[1]\n";
					$ep[$3][$info[1]]++;
				}
				
				last;
			}
		}
		
		close(TMP);
	}

}#for each line in temp classified file
					
$correct = 0;
$total = 0;
for ($i=0;$i<3;$i++)
{
	for($j=0;$j<3;$j++)
	{
		if($i==$j)
		{
			$correct = $correct + $ep[$i][$j];
		}
		$total = $total + $ep[$i][$j];
		print OUF "Expected = $i Predicted = $j Number = $ep[$i][$j]\n";
	}
}

print OUF "Percentage correct = ". $correct/$total . "\n";
close(OUF);
close(INF);

					
