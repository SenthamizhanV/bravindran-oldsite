#!/usr/bin/perl
#
# USAGE: perl join-train <cat-data-filename> <real-data-filename>

$cattrainer = $ARGV[0];
$realtrainer = $ARGV[1];


#generate filedsc.dat
#
open(OUF, ">./filedsc.txt");
open (INF, "dsctemplate.dat");
print OUF "\"$cattrainer\"\n";
while($line = <INF>)
{
	print OUF "$line";
}

close(OUF);
close(INF);



#generate input file input1 - corresponding to training file

$tmpClassified = "temp_classified.dat";
open(OUF,">./input1");
open(INF,"./inptemplate");
$num=0;
while($line = <INF>)
{
	$num++;
	if($num == 21)
	{
		print OUF "\"$cattrainer\"\n";
	}
	elsif($num == 22)
	{
		print OUF "$tmpClassified\n";
	}
	else
	{
		print OUF "$line";
	}
}
close(OUF);
close(INF);




#execute cruise
system("./cruise < input1");






#part4
#find nodes which require svm's
#
open(OUF, ">./model/tempManage.dat"); # manage file will contains nodeno:class:svm y/n:colon separated list of data serial nums
open(INF, "output");

while($line = <INF>)
{
	if($line =~ /[ ]+([0-9]+)[ ]+([0-9]+)[ ]+\*\*\*\* terminal, predicted class: ([0-9])/)
	{
		$node = $1;
		print OUF "$node:";
		$points = $2;
		$class = $3;
		print OUF "$class:";

		$line = <INF>; #skip
		while($line = <INF>)
		{
			if($line =~ /            Class $class :[ ]*([0-9]*)/)
			{
				if($1 == $points)
				{
					#if all points are in class $class
					print OUF "n\n";
				}
				else
				{
					print OUF "y";#svm required

					
					#contains info on which points are classified by which node.
					open(TMP, "$tmpClassified");
					$tmpline = <TMP>; #skipping the first line


					#temporary SVM trainer data file
					open(TMPRIN, ">./temp_svm_train.dat");
					#to get the continuous values frmo the real trainer file.
					open(TMP2, "$realtrainer");
					while($tmpline = <TMP>)
					{
						$svmdata = <TMP2>;
						if($tmpline =~ /[ ]*([0-9]+)[ ]+([0-9]+) ([0-9]) ([0-9])/)
						{
							if($2 == $node) #node matches
							{
								print OUF ":$1";
								print TMPRIN "$svmdata";
							}
						}
					}
					print OUF "\n";
					close(TMP);
					close(TMPRIN);
					close(TMP2);
					
					#call libsvm-trainer
					$model = "./model/svm" . $node . ".dat";
					system("./svm-scale -l 0 -u 1 ./temp_svm_train.dat > ./scaled_svm_train.dat");
					system("./svm-train -t 1 -d 2 -g 0.5 -r -5 -w1 1.41 -w2 2 ./scaled_svm_train.dat $model");
								
				}
				last;
			
			} #reg exp matches a class in "output"
		} #while ( = <INF>) used to loop the classes
		

	} # regex matches the terminal node
	
}#for each line in output file

	
close(OUF);
close(INF);
