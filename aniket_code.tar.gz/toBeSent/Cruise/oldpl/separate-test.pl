#!/usr/bin/perl
#
#

srand;
open(INPFILE, "treeform.dat");

open(TRAIN, ">roptrain.dat");
open(TEST, ">roptest.dat");

while($line = <INPFILE>)
{
	if(int(rand(5)) == 0)
	{
		print TEST  $line;
	}
	else
	{
		print TRAIN $line;
	}
}

