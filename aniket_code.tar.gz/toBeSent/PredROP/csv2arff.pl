#!/usr/bin/perl
#
#
# USAGE csv2arff <INPUT.csv> <OUTPUT.arff>
#
# Converts using the header stored in arfheader
#


$inputFile = $ARGV[0];
$outputFile = $ARGV[1];


@columns = (5,6,8,9,10,12,13,14,17,18,19,20,24,27,28,35,37,38,39,40,42,43,44,45,46,47,48,49,50,51,52,53,55,56,57,58,59,60,61,106,108,109,110,111,112,113);



open(HEADER, "arfheader");
open(INP, $inputFile);
open(OUT, ">$outputFile");

while($line = <HEADER>)
{
	print OUT "$line";
}

close(HEADER);


$line = <INP>;
while($line = <INP>)
{

	@names = split(/\:/,$line);
	print OUT $names[0];

	if(@names == 113)
	{
		foreach $col (@columns)
		{
			print OUT ",$names[$col-1]";
		}
	}
	elsif(@names == 47)
	{
		for($i = 1; $i < 47; $i++)
		{
			print OUT ",$names[$i]";
		}
	}
	else
	{
		print "Error: Can't Understand csv format\n";
		last;
	}
				
}

close(INP);
close(OUT);

