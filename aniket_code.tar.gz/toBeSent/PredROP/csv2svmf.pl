#!/usr/bin/perl
#
#
#USAGE: ./csv2svmf CSVFILE SVMFFILE
# Converts a csv file(colon separated) to format for libsvm

$csvfile = $ARGV[0];
$svmfile = $ARGV[1];

open (OUF, ">$svmfile");

open( HANDLE , "$csvfile");


@columns = (5,6,8,9,10,12,13,14,17,18,19,20,24,27,28,35,37,38,39,40,42,43,44,45,46,47,48,49,50,51,52,53,55,56,57,58,59,60,61,106,108,109,110,111,112,113);

$line = <HANDLE>;
while ($line = <HANDLE>)
{
	
	@names = split(/\:/,$line);
	
	if($names[0] == "?")
	{
		$names[0] = 0;
	}

	print OUF "$names[0]";	
	
	if(@names == 113)
	{
		$val=1;
		foreach $col (@columns)
		{
			print OUF " $val\:$names[$col-1]";
			$val=$val+1;
		}
	}
	elsif(@names == 47)
	{
		for($val = 1; $val<47; $val++)
		{
			print OUF " $val\:$names[$val]";
		}
	}
	else
	{
		print "Error:Can't Understand format of csv\n";
		last;
	}

}
close(OUF);
close(HANDLE);
