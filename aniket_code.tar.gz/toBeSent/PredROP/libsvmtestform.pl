#!/usr/bin/perl
#
# USAGE: ./libsvmtestform TESTER svm-predictoutputfile
#

$testfile = $ARGV[0];
$outfile = $ARGV[1];

open(INP1,"$testfile");
open(INP2, "$outfile");

$current = 1;
while($line = <INP1>)
{
	$line2 = <INP2>;
	if($line =~ /([\d]+) .+/)
	{
		$exp = $1;
		if($line2 =~ /([\d]+)/)
		{
			print "S.No. = $current Correct Class = ".$exp. " Predicted Class = $1\n";
			$current++;
		}
	}
}
close(INP1);
close(INP2);
