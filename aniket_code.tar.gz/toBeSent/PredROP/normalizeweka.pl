#!/usr/bin/perl
#
# USAGE: ./normalizeweka TRAININGFILE nTRAININGFILE TESTINGFILE nTESTINGFILE
#

$trainInput = $ARGV[0];
$trainOutput = $ARGV[1];
$testInput = $ARGV[2];
$testOutput = $ARGV[3];
$normalTemp = "./tmp/ntemp.arff";
$nTempOut = "./tmp/ntempout.arff";

open(TRINP,"$trainInput");
open(TEINP,"$testInput");

open(OUP,">$normalTemp"); #temporary file which stores prenormalized results

$num=0;
$reached = 0;

#write the whole trainingfile (arff) into ntemp.arff
while($line = <TRINP>)
{
	if($reached == 1)
	{
		$num++;
	}
	print OUP $line;

	if($line =~ /\@data/)
	{
		last;
	}
}



while($line = <TRINP>)
{
	if($line ne "\n") #skip empty lines
	{
		$num++;
		print OUP $line;
	}
}

close(TRINP);


#open the final result files for normalized output
open(NTR, ">$trainOutput");
open(NTE, ">$testOutput");


$reached = 0;


#this part writes the whole arff header (from the test file) in the two output files
#it also writes all the data from the test file to the ntemp.arff
while($line = <TEINP>)
{
	if($reached == 1)
	{
		if($line ne "\n")
		{
			print OUP $line;
		}
	}
	else
	{
		print NTR $line;
		print NTE $line;
		
		if($line =~ /\@data/)
		{
			$reached = 1;
		}
	}
}

close(TEINP);	
close(OUP);


#normalize the combined file ntemp.arff
system("java weka.filters.unsupervised.attribute.Normalize -i $normalTemp -o $nTempOut");


#now we have to divide the combined normalized output file
#we do it based on the fact that $num stores number of
# data in training file
open (NINP, "$nTempOut");

$tnum=0;
$reached = 0;
while($line = <NINP>)
{
	
	if($reached == 1)
	{
		if($line ne "\n")
		{
			$tnum++;
			if ($tnum <= $num)
			{
				print NTR $line;
			}
			else
			{
				print NTE $line;
			}
		}
	}

	if($line =~ /\@data/)
	{
		$reached = 1;
	}
}

close (NTR);
close(NTE);
close(NINP);
