#!/usr/bin/perl
#
#
# Script to run package from command line
#
# USAGE: runpkg.pl <Classification Model> <TrainingFile> <Test file(optional)>
#
# Training and test files to be in .csv
# Aniket Ray
# April 25, 2007
# 
#
# TODO: Add the ability to save models
# 	for this make 2 version of the file, trainmodel.pl and loadmodel.pl
# 	Build a GUI on top of this




#check correct arguments
if((@ARGV != 3) && (@ARGV != 2))
{
	print "Error: Parsing arguments\n";
	print "USAGE: runpkg.pl <Classification Model> <TrainingFile> <Test file(optional)>\n";
	exit -1;
}


#fix whether cross validation or testfile
if(@ARGV == 3)
{
	$withTest = 1;
	$modelName = $ARGV[0];
	$trainFile = $ARGV[1];
	$testFile = $ARGV[2];
}
else
{
	$withTest = 0;
	$modelName = $ARGV[0];
	$trainFile = $ARGV[1];
}





#read settings file
open(SETFILE, ".settings");
while($line = <SETFILE>)
{
	#read required settings

}

close(SETFILE);


#read modelfile
#
#Model file features
# if line starts with # then comment
#
#
# Two 3 line triplets for each model
# MODELID:
# format convertor to convert training file to desired
# command line to run for cv(will be executed in system verbatim)
# output parser to run for cv(will be executed in system verbatim)
# format convertor for test file
# command line to run for test(will be executed in system verbatim)
# output parser to run for test(will be executed in system verbatim)
# check modelinfo.hlp for details
open(MODFILE, ".modelinfo");
$modelFound = 0;
@systemCommand[6];
while($line = <MODFILE>)
{
	if($line =~ /#.*/)      	#skip comment lines
	{
		#figure out: The world in not Bond's.
	}
	elsif($line =~ /model\:$modelName\:.*/)   #find the model id from the whole list
	{
		$modelFound = 1;
		$nextRead = 0;
	}
	elsif($modelFound == 1)#if we have found the model name in the lest
	{
		if($nextRead<6) #if then the next 6 lines have been read
		{
			$systemCommand[$nextRead] = $line;
			$nextRead++;
		}
		else #if 6 lines read
		{
			last;
		}
	}
}

close(MODFILE);



#if model does not match
# show error, list of available models and pack.
if($modelFound == 0)
{
	print "Error: Mentioned Model not found\n";
	print "List of Models available:\n";
	open(MODFILE, ".modelinfo");
	while($line = <MODFILE>)
	{
		if($line =~ /model\:(.*)\:(.*)/)
		{
			print "MODEL ID: $1";
			print "  Description: $2\n";
		}
	}
	close(MODFILE);
	exit -1;
}


#at this point we have model and required commands stored


#converting the training file to the required format

$trainerTrans = $systemCommand[0];
if($trainerTrans =~ /OUTFORM\.([\S]+)?[.]*/)
{
	$trainerExt = $1; #storing the extension of the outputform
}


$trainerTrans =~ s/RAWTRAINER/$trainFile/g;
$trainerTrans =~ s/OUTFORM/\.\/tmp\/train/g;
$trainerTrans =~ s/TEMPER/\.\/tmp\/temp/g;
system($trainerTrans); # convert the input format to output format
#print($trainerTrans);

$procTrainer = "./tmp/train.".$trainerExt; #processed trainer Filename


#run the individual programs
$tmpOut = "./tmp/tmp.out";
if($withTest == 0) #only a cross validation
{
	$systemCommand[1] =~ s/TRAINER/$procTrainer/g;
	$systemCommand[1] =~ s/OUTPUT/$tmpOut/g;
	$systemCommand[1] =~ s/TEMPER/\.\/tmp\/temp/g;
	$systemCommand[2] =~ s/OUTPUT/$tmpOut/g;
	$systemCommand[2] =~ s/TEMPER/\.\/tmp\/temp/g;


	system($systemCommand[1]);
#	print($systemCommand[1]);
	system($systemCommand[2]);
#	print($systemCommand[2]);
	
}
else
{
	#converting the testing file to the required format
	$testerTrans = $systemCommand[3];
	if($testerTrans =~ /OUTFORM\.([\S]+)?[.]*/)
	{
		$testerExt = $1; #storing the extension of the outputform
	}
	
	$testerTrans =~ s/RAWTESTER/$testFile/g;
	$testerTrans =~ s/OUTFORM/\.\/tmp\/test/g;
	$testerTrans  =~ s/TEMPER/\.\/tmp\/temp/g;
#	print($testerTrans);
	system($testerTrans); # convert the input format to output format
	$procTester = "./tmp/test.".$testerExt;
	
	

	$systemCommand[4] =~ s/TRAINER/$procTrainer/g;
	$systemCommand[4] =~ s/TESTER/$procTester/g;
	$systemCommand[4] =~ s/OUTPUT/$tmpOut/g;
	$systemCommand[4] =~ s/TEMPER/\.\/tmp\/temp/g;
	$systemCommand[5] =~ s/OUTPUT/$tmpOut/g;
	$systemCommand[5] =~ s/TEMPER/\.\/tmp\/temp/g;

#	print($systemCommand[4]);
	system($systemCommand[4]);
#	print($systemCommand[5]);
	system($systemCommand[5]);
	
}
	
