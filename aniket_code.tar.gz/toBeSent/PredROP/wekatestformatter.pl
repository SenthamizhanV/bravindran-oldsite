#!/usr/bin/perl
#
# USAGE: ./wekatestformatter wekaoutputfile
#

$infile = $ARGV[0];

open(INP,"$infile");

while($line = <INP>)
{
	if($line =~ /([\d]+) ([\d]+) ([\d](\.[\d]+)?) ([\d]+) /)
	{
		print "S.No. = $1 Correct Class = ".$5. " Predicted Class = $2\n";
	}
}
