#!/usr/bin/perl
#
# USAGE: ./wekatrainformatter wekaoutputfile
#

$infile = $ARGV[0];

open(INP,"$infile");

$reached = 0;
@ep = ([0,0,0],[0,0,0],[0,0,0]);
while($line = <INP>)
{
	if($line =~ /=== Stratified cross-validation ===/)
	{
		$reached = 1;
		$current = 0;
		$total = 0;
	}
	if($reached == 1)
	{
		if($line =~ /Correctly Classified Instances[\s]+[\d]+[\s]+([\d]+(\.[\d]+)?) %/)
		{
			$accuracy = $1;
		}

#		print $line;
		if($line =~ /[\s]*([\d]+)[\s]+([\d]+)[\s]+([\d]+) \|.+/)
		{
#			print "Confusion Matrix\n";
#			print "\t0\t1\t2\t<---Classified as\n";
#			for($i=0; $i<3; $i++)
#			{
#				for($j=0; $j<3; $j++)
#				{
#					print "\t$ep[$i][$j]";
#				}
#				print " |\t$i\n";
#			}
			$ep[$current][0] = $1;

			$ep[$current][1] = $2;
			$ep[$current][2] = $3;
			$total += $1 + $2 + $3;
			$current++;
		}
	}	

}

close(INP);

print "== Two class case ==\n";
for($i=0;$i<3;$i++)
{
	$totalClass0 = $totalClass0 + $ep[0][$i];
	$totalClass2 = $totalClass2 + $ep[2][$i];
}

$accu2class = ($ep[0][0]+$ep[2][1]+$ep[2][2]) / ($totalClass0 + $totalClass2);
print "Accuracy = $accu2class \n";
print "Sensitivity = ".($ep[2][1]+$ep[2][2])/$totalClass2."\n";
print "Specificity = ".($ep[0][0]/$totalClass0)."\n";
print "False -ve = ".($ep[2][0]/$totalClass2)."\n";


print "=== Three class case ===\n";
print "Accuracy = $accuracy \n";
print "Sensitivity = ".$ep[2][2]/$totalClass2."\n";
print "Specificity = ".$ep[0][0]/$totalClass0."\n";
print "False -ve = ".($ep[2][0]/$totalClass2)."\n";


print "Confusion Matrix\n";
print "\t0\t1\t2\t<---Classified as\n";
for($i=0; $i<3; $i++)
{
	for($j=0; $j<3; $j++)
	{
		print "\t$ep[$i][$j]";
	}
	print " |\t$i\n";
}

