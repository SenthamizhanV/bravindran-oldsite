#!/usr/bin/perl
#
#
# Does 5 fold Cross validation each on bagging with svms

$d = ".dat";
$train = "bfld/train";
$test = "bfld/test";
$model = "Model";

$bags=11; #number of bags.

$t = "tmp/train.dat";
$str = "tmp/scltrain.dat";
$ste = "tmp/scltest.dat";
$to = "tmp/out";

for($i=1; $i<=5; $i++)
{
	$trainer = $train.$i.$d;
	$tester = $test.$i.$d;
	$num = 0;
	$numtest = 0;
	open(INF, "$trainer");
	while($line = <INF>)
	{
		$num++;
	}
	close(INF);
		
	open(INF, "$tester");
	while($line = <INF>)
	{
		$numtest++;
	}
	close(INF);
		
	
	$tmp = "./svm-scale -l 0 -u 1 $tester > $ste";
	system($tmp);
	
	for($j=1; $j<=$bags; $j++)
	{
		@numtimes;
		for($k=0; $k<$num ;$k++)
		{
			$numtimes[$k] = 0;
		}

		for($k=0;$k<$num;$k++)
		{
			$numtimes[int(rand(10000))%$num]++;
		}

		open(INF, "$trainer");
		open(OUF, ">$t");
		for($k=0; $k<$num; $k++)
		{
			$line = <INF>;
			while($numtimes[$k] > 0)
			{
				print OUF $line;
				$numtimes[$k]--;
			}

		}	
		close (OUF);
		close (INF);



		$tmp = "./svm-scale -l 0 -u 1 $t > $str";
		system("$tmp");
		$tmp="./svm-train -t 1 -d 2 -g 0.05 -r 1 -c 10 ".$str." ".$model."_".$j ;
		system("$tmp");
		$tmp = "./svm-predict ".$ste." ".$model."_".$j." ".$to.$j;
		system("$tmp");
	}
	

	for($j=0; $j<$numtest; $j++)
	{
		$c[0][$j] = 0;
		$c[1][$j] = 0;
		$c[2][$j] = 0;
	}
	
	@c;
	for($j=1; $j<=$bags; $j++)
	{
		$file = $to.$j;
		open(INF, $file);

		
		for($k=0;$k<$numtest;$k++)
		{
#			print "$c[0][$k]:$c[1][$k]:$c[2][$k]\n";
			$line = <INF>;
			$c[substr($line,0,1)][$k]++;
		}

		close(INF);
	}
	for($k=0;$k<$numtest;$k++)
	{
		print "$c[0][$k]:$c[1][$k]:$c[2][$k]\n";
	}


	$file = "pred".$i;
	open(INF, "$tester");
	open(OUF, ">$file");
		
	@conmat = ([0,0,0],[0,0,0],[0,0,0]);
	
	for($j=0; $j<$numtest; $j++)
	{
		$line = <INF>;
		$exp = substr($line,0,1);
		print OUF $j+1;
		print OUF ":$exp:";
		
		$pred = 0;
		for($k=1;$k<=2;$k++)
		{
			if($c[$k][$j] >= $c[$pred][$j])
			{
				$pred = $k;
			}

		}

		print OUF $pred."\n";

		$conmat[$exp][$pred]++;
	}

	close(INF);
	
	$total = 0;
	$correct = 0;
	for($j = 0; $j < 3 ; $j++)
	{
		for($k = 0; $k < 3; $k++)
		{
			if($j==$k)
			{
				$correct = $correct + $conmat[$j][$k];
			}
			$total = $total + $conmat[$j][$k];
			print OUF "Expected = $j Predicted = $k Number = $conmat[$j][$k]\n";
		}
	}

	print OUF "Percentage correct = ". $correct/$total . "\n";
	close(OUF);
}


