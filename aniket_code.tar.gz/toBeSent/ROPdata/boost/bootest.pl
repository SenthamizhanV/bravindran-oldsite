#!/usr/bin/perl
#
#USAGE: perl bootest.pl <tester> <model> <output>

srand;

$tester = $ARGV[0];
$model = $ARGV[1];
$output = $ARGV[2];

$t1 = "./tmp/t1.dat"; #scaled initial
$t2 = "./tmp/t2.dat"; #output model_a
$t3 = "./tmp/t3.dat"; #output model_b
$t4 = "./tmp/t4.dat"; #output model_c

$t5a = "./tmp/t5a.dat"; #correct classification
$t5b = "./tmp/t5b.dat"; #incorrect classification
$t6 = "./tmp/t6.dat"; #remaining
$t4 = "./tmp/t7.dat"; #outputs from svm2testing

#scale tester
#
system("./svm-scale -l 0 -u 1 $tester > $t1");



#test all 3 models
$modelA = $model . "_A";
$modelB = $model . "_B";
$modelC = $model . "_C";

system("./svm-predict $t1 $modelA $t2");
system("./svm-predict $t1 $modelA $t3");
system("./svm-predict $t1 $modelA $t4");

#add correct to t5 incorrect to t6
open(INF, "$t2");
open(INF2, "$t3");
open(INF3, "$t4");
open(INF4, "$t1");

open(OUF, ">$output");

@count = (0,0,0);
@conmat = ([0,0,0],[0,0,0],[0,0,0]); 
$sno=0;
while($line = <INF>)
{
	$line2 = <INF2>;
	$line3 = <INF3>;
	$line4 = <INF4>;
	
	$count[substr($line,0,1)]++;
	$count[substr($line2,0,1)]++;
	$count[substr($line3,0,1)]++;
	$sno++;

	$exp = substr($line4,0,1);
	print OUF $sno.":".$exp . ":";
	
	$pred = 0;
	for($i=1; $i<3; $i++)
	{
		if($count[$i] >= $count[$pred])
		{
			$pred = $i;
		}
	}
		
	$count[0] = 0;	
	$count[1] = 0;	
	$count[2] = 0;	

	print OUF $pred ."\n";

	$conmat[$exp][$pred]++;

	
}

close(INF);
close(INF2);
close(INF3);
close(INF4);

$total = 0;
$correct = 0;
for($i = 0; $i < 3 ; $i++)
{
	for($j = 0; $j < 3; $j++)
	{
		if($i==$j)
		{
			$correct = $correct + $conmat[$i][$j];
		}
		$total = $total + $conmat[$i][$j];
		print OUF "Expected = $i Predicted = $j Number = $conmat[$i][$j]\n";
	}
}

print OUF "Percentage correct = ". $correct/$total . "\n";
close(OUF);
														
