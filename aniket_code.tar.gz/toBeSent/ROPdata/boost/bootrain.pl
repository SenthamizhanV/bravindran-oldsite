#!/usr/bin/perl
#
#USAGE: perl bootrain.pl <trainer> <model>

srand;

$trainer = $ARGV[0];
$model = $ARGV[1];

$t1 = "./tmp/t1.dat"; #scaled initial
$t2 = "./tmp/t2.dat"; #used for svm training
$t3 = "./tmp/t3.dat"; #remaining
$t4 = "./tmp/t4.dat"; #outputs from svm testing
$t5a = "./tmp/t5a.dat"; #correct classification
$t5b = "./tmp/t5b.dat"; #incorrect classification
$t6 = "./tmp/t6.dat"; #remaining
$t7 = "./tmp/t7.dat"; #outputs from svm2testing

#scale trainer
#
system("./svm-scale -l 0 -u 1 $trainer > $t1");



#1/3 ->t2.dat
#
open (OUF, ">$t2");
open (OUF2, ">$t3");
open (INF, "$t1");
while($line = <INF>)
{
	$k = int(rand(999));
	if($k < 333)
	{
		print OUF "$line";
	}
	else
	{
		print OUF2 "$line";
	}
}

close(OUF);
close(OUF2);
close(INF);


#train svm
$modelA = $model . "_A";
system("./svm-train -t 1 -d 2 -g 0.05 -r 1 -c 10 $t2 $modelA");

#test untested
print "\n./svm-predict $t3 $modelA $t4";
system("./svm-predict $t3 $modelA $t4");

#add correct to t5 incorrect to t6
open(INF, "$t3");
open(INF2, "$t4");
open(OUF1, ">$t5a");
open(OUF2, ">$t5b");
open(OUF3,">$t6");

$numC = 0;
$numW = 0;
while($line = <INF>)
{
	$line2 = <INF2>;
	$k = int(rand(1000));
	
	if($k < 500)
	{
		if(substr($line1,0,1) == substr($line2,0,1))
		{
			print OUF1 $line;
			$numC++;
		}
		else
		{
			print OUF2 $line;
			$numW++;
		}
	}
	else
	{
		print OUF3 $line;
	}

}

close(INF);
close(INF2);
close(OUF1);
close(OUF2);
close(OUF3);

$smallC = -1;
if($numC < $numW)
{
	$numInB =  $numC;
	$large = $numW;
	$smallC = 1; 
}
else
{
	$numInB = $numW;
	$large = $numC;
	$smallC = 0;
}



open(INF, "$t5a");
open(INF2, "$t5b");
open(OUF, ">$t2");

if($smallC == 1)
{
	while($line = <INF>)
	{
		print OUF $line;
	}

}
else
{
	while($line = <INF2>)
	{
		print OUF $line;
	}
}

#generate an array storing $numInB random numbers between 0 and $large-1
#@rands;
@rndinvs;
for($i=0;$i<$large;$i++)
{
	$rndinvs[$i]=0;
}
	
for($i = 0; $i < $numInB; $i++)
{
	$k = int(rand($large));
	while($rndinvs[$k] !=0)
	{
		$k = ($k + 1) % $large;
	}

	$rndinvs[$k] = 1;
}

for($i = 0;$i<$large;$i++)
{
	if($rndinvs[$i] == 1)
	{
		print $i." ";
	}
}
print "\n";




$num = 0;

if($smallC == 1)
{
	while ($num < $large)
	{
		if($rndinvs[$num] == 1)
		{
			$line2 = <INF2>;
			print OUF $line2;
		}
		$num++;
	}
	
}
else
{
	while ($num < $large)
	{
		if($rndinvs[$num] == 1)
		{
			$line = <INF>;
			print OUF $line;
		}
		$num++;
	}
	
}


close(INF);
close(INF2);
close(OUF);

#train svm2
$modelB = $model . "_B";
system("./svm-train -t 1 -d 2 -g 0.05 -r 1 -c 10 $t2 $modelB");


#test remaining data
system("./svm-predict $t6 $modelA $t4");
system("./svm-predict $t6 $modelB $t7");

#test if both a and b match

open(INF, "$t4");
open(INF2,"$t7");
open(INF3, "$t6");
open(OUF, ">$t2");

while($line = <INF>)
{
	$line2 = <INF2>;
	$line3 = <INF3>;
		if(substr($line1,0,1) != substr($line2,0,1))
		{
			print OUF $line3;
		}
}

close(INF);
close(INF2);
close(INF3);
close(OUF);



#train svm3
$modelC = $model . "_C";
system("./svm-train -t 1 -d 2 -g 0.05 -r 1 -c 10 $t2 $modelC");

print "Training Complete\n";
