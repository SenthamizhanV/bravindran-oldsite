#!/usr/bin/perl
#
#
#

$d = ".dat";
$train = "bfld/train";
$test = "bfld/test";
$model = "Model";

for($i=1; $i<=5; $i++)
{
	$tmp="perl bootrain.pl ".$train.$i.$d." $model" ;
	system("$tmp");
	$tmp = "perl bootest.pl ".$test.$i.$d." ".$model." pred".$i;
	system("$tmp");
}
				

