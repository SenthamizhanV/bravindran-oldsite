#!/usr/bin/perl

#deprecated file
# This was used to convert the csv file to a format that can be read by the Cruise Tree Package
# The format of the input .xls (hence the csv) file has changed since then
# 

open (INF, ">./treeform.dat");

open( HANDLE1 , "./att.csv");

print "opened";
@columns = (9,11,13,15,19,20,29,30,36,39,40,41,43,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,107,109,110,111,112,113,114); #columns in data file to be used as features
%missing = ("11",0,"55",1,"109",2,"110",2,"111",2); #the columns with missing values followed by value that indicates missing value
$line = <HANDLE>;
$lineNum=0;
while ($line = <HANDLE1>)
{
	$lineNum++;
	if($lineNum != 250)
	{
		#print $line;
		@names = split(/\:/,$line);


		print INF "$names[0]";	

		foreach $col (@columns)
		{
			if(($col == 11)||($col == 55)||($col == 109)||($col == 110)||($col == 111))
			{
				#		print "$missing{$col} ";
				if($names[$col-1] == $missing{$col})
				{
					print INF ",\?";
				}
				else
				{
					print INF ",$names[$col-1]";
				}
			}
			else
			{
				print INF ",$names[$col-1]";
			}
		}
	}
#	else
#	{
#		#	print INF "\n";
#	}
}
print "finished";						
