#!/usr/bin/perl


#creates 5 separate data sets each for real and categorical varibles
#used for cross validation
#

srand;

open (CAT, "./cat-common.dat");
open (REAL, "./real-common.dat");


open(CTEST1, ">./folded/cattest1.dat");
open(CTEST2, ">./folded/cattest2.dat");
open(CTEST3, ">./folded/cattest3.dat");
open(CTEST4, ">./folded/cattest4.dat");
open(CTEST5, ">./folded/cattest5.dat");

open(CTRAIN1, ">./folded/cattrain1.dat");
open(CTRAIN2, ">./folded/cattrain2.dat");
open(CTRAIN3, ">./folded/cattrain3.dat");
open(CTRAIN4, ">./folded/cattrain4.dat");
open(CTRAIN5, ">./folded/cattrain5.dat");

open(RTEST1, ">./folded/realtest1.dat");
open(RTEST2, ">./folded/realtest2.dat");
open(RTEST3, ">./folded/realtest3.dat");
open(RTEST4, ">./folded/realtest4.dat");
open(RTEST5, ">./folded/realtest5.dat");

open(RTRAIN1, ">./folded/realtrain1.dat");
open(RTRAIN2, ">./folded/realtrain2.dat");
open(RTRAIN3, ">./folded/realtrain3.dat");
open(RTRAIN4, ">./folded/realtrain4.dat");
open(RTRAIN5, ">./folded/realtrain5.dat");

open(MAPPER, ">./folded/mapper.dat");
open(INVMAP1, ">./folded/invmap1.dat");
open(INVMAP2, ">./folded/invmap2.dat");
open(INVMAP3, ">./folded/invmap3.dat");
open(INVMAP4, ">./folded/invmap4.dat");
open(INVMAP5, ">./folded/invmap5.dat");

open(INVTEST1, ">./folded/invtestmap1.dat");
open(INVTEST2, ">./folded/invtestmap2.dat");
open(INVTEST3, ">./folded/invtestmap3.dat");
open(INVTEST4, ">./folded/invtestmap4.dat");
open(INVTEST5, ">./folded/invtestmap5.dat");

print "opened\n";

$cline = <CAT>;
$rline = <REAL>;
$num = 0;
while ($cline = <CAT>)
{
	$rline = <REAL>;
	
	$num++;
	$r=int(rand(5)) + 1;


	print MAPPER "$num,", $r, "\n";
		
	if($r == 1)
	{
		
		print RTEST1 "$rline";
		print CTEST1 "$cline";
		print INVTEST1 "$num\n";

		print RTRAIN2 "$rline";
		print RTRAIN3 "$rline";
		print RTRAIN4 "$rline";
		print RTRAIN5 "$rline";

		print CTRAIN2 "$cline";
		print CTRAIN3 "$cline";
		print CTRAIN4 "$cline";
		print CTRAIN5 "$cline";

		print INVMAP2 "$num\n";
		print INVMAP3 "$num\n";
		print INVMAP4 "$num\n";
		print INVMAP5 "$num\n";
	}
	elsif($r == 2)
	{
		
		print RTEST2 "$rline";
		print CTEST2 "$cline";
		print INVTEST2 "$num\n";

		print RTRAIN1 "$rline";
		print RTRAIN3 "$rline";
		print RTRAIN4 "$rline";
		print RTRAIN5 "$rline";

		print CTRAIN1 "$cline";
		print CTRAIN3 "$cline";
		print CTRAIN4 "$cline";
		print CTRAIN5 "$cline";
	
		print INVMAP1 "$num\n";
		print INVMAP3 "$num\n";
		print INVMAP4 "$num\n";
		print INVMAP5 "$num\n";
	}
	elsif($r == 3)
	{
		print RTEST3 "$rline";
		print CTEST3 "$cline";
		print INVTEST3 "$num\n";

		print RTRAIN1 "$rline";
		print RTRAIN2 "$rline";
		print RTRAIN4 "$rline";
		print RTRAIN5 "$rline";

		print CTRAIN1 "$cline";
		print CTRAIN2 "$cline";
		print CTRAIN4 "$cline";
		print CTRAIN5 "$cline";
	
		print INVMAP1 "$num\n";
		print INVMAP2 "$num\n";
		print INVMAP4 "$num\n";
		print INVMAP5 "$num\n";
	}
	elsif($r == 4)
	{
		print RTEST4 "$rline";
		print CTEST4 "$cline";
		print INVTEST4 "$num\n";

		print RTRAIN1 "$rline";
		print RTRAIN2 "$rline";
		print RTRAIN3 "$rline";
		print RTRAIN5 "$rline";

		print CTRAIN1 "$cline";
		print CTRAIN2 "$cline";
		print CTRAIN3 "$cline";
		print CTRAIN5 "$cline";
	
		print INVMAP1 "$num\n";
		print INVMAP2 "$num\n";
		print INVMAP3 "$num\n";
		print INVMAP5 "$num\n";
	}
	elsif($r == 5)
	{
		print RTEST5 "$rline";
		print CTEST5 "$cline";
		print INVTEST5 "$num\n";

		print RTRAIN1 "$rline";
		print RTRAIN2 "$rline";
		print RTRAIN3 "$rline";
		print RTRAIN4 "$rline";

		print CTRAIN1 "$cline";
		print CTRAIN2 "$cline";
		print CTRAIN3 "$cline";
		print CTRAIN4 "$cline";
	
		print INVMAP1 "$num\n";
		print INVMAP2 "$num\n";
		print INVMAP3 "$num\n";
		print INVMAP4 "$num\n";
	}
	
}	
	
	
print "finished\n";						
