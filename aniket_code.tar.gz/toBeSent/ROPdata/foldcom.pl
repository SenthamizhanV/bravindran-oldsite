#!/usr/bin/perl
#
#open the final.dat and divides the data points into 5 data sets which can be used by other files 
# for cross validation
# 

srand;

open( HANDLE1 , "./final.dat");



open(TEST1, ">./bfld/test1.dat");
open(TEST2, ">./bfld/test2.dat");
open(TEST3, ">./bfld/test3.dat");
open(TEST4, ">./bfld/test4.dat");
open(TEST5, ">./bfld/test5.dat");

open(TRAIN1, ">./bfld/train1.dat");
open(TRAIN2, ">./bfld/train2.dat");
open(TRAIN3, ">./bfld/train3.dat");
open(TRAIN4, ">./bfld/train4.dat");
open(TRAIN5, ">./bfld/train5.dat");

open(MAPPER, ">./bfld/mapper.dat");
open(INVMAP1, ">./bfld/invmap1.dat");
open(INVMAP2, ">./bfld/invmap2.dat");
open(INVMAP3, ">./bfld/invmap3.dat");
open(INVMAP4, ">./bfld/invmap4.dat");
open(INVMAP5, ">./bfld/invmap5.dat");

open(INVTEST1, ">./bfld/invtestmap1.dat");
open(INVTEST2, ">./bfld/invtestmap2.dat");
open(INVTEST3, ">./bfld/invtestmap3.dat");
open(INVTEST4, ">./bfld/invtestmap4.dat");
open(INVTEST5, ">./bfld/invtestmap5.dat");

@times = (1,1,1); #was used to introduce a sample bias (1,2,1) implies that the second class data points will be doubled
print "opened\n";

#$line = <HANDLE1>;

$num = 0;
while ($line = <HANDLE1>)
{
	
	$num++;
	$r=int(rand(5)) + 1;

	$class = substr($line,0,1);
	
	print MAPPER "$num,", $r, "\n";

	for($i=0;$i<$times[$class];$i++)
	{	
		if($r == 1)
		{

			print TEST1 "$line";
			print INVTEST1 "$num\n";

			print TRAIN2 "$line";
			print TRAIN3 "$line";
			print TRAIN4 "$line";
			print TRAIN5 "$line";

			print INVMAP2 "$num\n";
			print INVMAP3 "$num\n";
			print INVMAP4 "$num\n";
			print INVMAP5 "$num\n";
		}
		elsif($r == 2)
		{

			print TEST2 "$line";
			print INVTEST2 "$num\n";

			print TRAIN1 "$line";
			print TRAIN3 "$line";
			print TRAIN4 "$line";
			print TRAIN5 "$line";

			print INVMAP1 "$num\n";
			print INVMAP3 "$num\n";
			print INVMAP4 "$num\n";
			print INVMAP5 "$num\n";
		}
		elsif($r == 3)
		{
			print TEST3 "$line";
			print INVTEST3 "$num\n";

			print TRAIN1 "$line";
			print TRAIN2 "$line";
			print TRAIN4 "$line";
			print TRAIN5 "$line";

			print INVMAP1 "$num\n";
			print INVMAP2 "$num\n";
			print INVMAP4 "$num\n";
			print INVMAP5 "$num\n";
		}
		elsif($r == 4)
		{
			print TEST4 "$line";
			print INVTEST4 "$num\n";

			print TRAIN1 "$line";
			print TRAIN2 "$line";
			print TRAIN3 "$line";
			print TRAIN5 "$line";

			print INVMAP1 "$num\n";
			print INVMAP2 "$num\n";
			print INVMAP3 "$num\n";
			print INVMAP5 "$num\n";
		}
		elsif($r == 5)
		{
			print TEST5 "$line";
			print INVTEST5 "$num\n";

			print TRAIN1 "$line";
			print TRAIN2 "$line";
			print TRAIN3 "$line";
			print TRAIN4 "$line";

			print INVMAP1 "$num\n";
			print INVMAP2 "$num\n";
			print INVMAP3 "$num\n";
			print INVMAP4 "$num\n";
		}
	}#closes for times
}	
	
	
print "finished\n";						
