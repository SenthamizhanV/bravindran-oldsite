
open(INPFILE1, "./newoutput");
open(INPFILE2, "./newoutput2");

open(LINFILE, ">./lintbl-n.dat");
open(POLFILE, ">./poltbl-n.dat");

open(RBFFILE, ">./rbftbl-n.dat");
open(SIGFILE, ">./sigtbl-n.dat");

$curr=1; #1=>lin, 2 =>pol ...

while($line = <INPFILE1>)
{
	if($line =~ /Linear Kernel: Cost = ([0-9\.]*) , Epsilon = ([0-9\.]*)/)
	{
		print LINFILE "$1";
		while($line = <INPFILE1>)
		{
			if($line =~ /Cross Validation Accuracy = ([0-9\.]*)%/)
			{
				print LINFILE "\t$1\n";
				last;
			}
		
		}
	}
	elsif ($line =~ /Polynomial Kernel: Degree = ([0-9\.]*), Gamma = ([0-9\.]*), Coeff = (\-?[0-9\.]*), Cost = ([0-9\.]*), Epsilon = ([0-9\.]*)/)
	{
		print POLFILE "$1\t$2\t$3\t$4";
		while($line = <INPFILE1>)
		{
			if($line =~ /Cross Validation Accuracy = ([0-9\.]*)%/)
			{
				print POLFILE "\t$1\n";
				last;
			}
		
		}
	}
}


while($line = <INPFILE2>)
{
	if ($line =~ /Gaussian Kernel: Gamma = ([0-9\.]*), Cost = ([0-9\.]*), Epsilon = ([0-9\.]*)/)
	{
		print RBFFILE "$1\t$2";
		while($line = <INPFILE2>)
		{
			if($line =~ /Cross Validation Accuracy = ([0-9\.]*)%/)
			{
				print RBFFILE "\t$1\n";
				last;
			}
		}
	}
	elsif ($line =~ /Sigmoid Kernel: Gamma = ([0-9\.]*), Coeff = (\-?[0-9\.]*), Cost = ([0-9\.]*), Epsilon = ([0-9\.]*)/)
	{
		print SIGFILE "$1\t$2\t$3";
		while($line = <INPFILE2>)
		{
			if($line =~ /Cross Validation Accuracy = ([0-9\.]*)%/)
			{
				print SIGFILE "\t$1\n";
				last;
			}
		}
	}
}

close(INPFILE);
close(LINFILE);
close(POLFILE);
close(SIGFILE);

																																		
