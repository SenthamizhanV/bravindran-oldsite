#!/usr/bin/perl

$trainfile = "./scaled-final38.dat";

@costs = (0.1,0.5,1,10,100,1000,5000);
@degrees = (2,3,4,5);
@gammas = (0.0001,0.0005,0.001,0.005,0.01,0.05,0.1,0.5);
@epsilons = (0.0001);
@coeffs = (-100,-50,-10,-5,-1,0,1,5,10,50,100);

#kernel Type 0 => linear
foreach $c (@costs)
{
	foreach $e (@epsilons)
	{
		print "Linear Kernel: Cost = $c , Epsilon = $e\n";
		system "./svm-train -t 0 -c $c -e $e -v 5 $trainfile";
		print "----------------------------------------\n";
	}
}



#kernel Type 1 => polynomial
foreach $d (@degrees)
{
	foreach $g (@gammas)
	{
		foreach $coef (@coeffs)
		{
			foreach $c (@costs)
			{
				foreach $e (@epsilons)
				{
					print "Polynomial Kernel: Degree = $d, Gamma = $g, Coeff = $coef, Cost = $c, Epsilon = $e\n" ;
					system "./svm-train -t 1 -d $d -g $g -r $coef -c $c -e $e -v 5 $trainfile";
					print "----------------------------------------\n";
				}
			}
		}
	}
}



#kernel Type 2 => RBF
foreach $g (@gammas)
{
	foreach $c (@costs)
	{
		foreach $e (@epsilons)
		{
			print "Gaussian Kernel: Gamma = $g, Cost = $c, Epsilon = $e\n" ;
			system "./svm-train -t 2 -g $g -c $c -e $e -v 5 $trainfile";
			print "----------------------------------------\n";
		}
	}
}


#kernel Type 3 => Sigmoid
foreach $g (@gammas)
{
	foreach $coef (@coeffs)
	{
		foreach $c (@costs)
		{
			foreach $e (@epsilons)
			{
				print "Sigmoid Kernel: Gamma = $g, Coeff = $coef, Cost = $c, Epsilon = $e\n" ;
				system "./svm-train -t 3 -g $g -r $coef -c $c -e $e -v 5 $trainfile";
				print "----------------------------------------\n";
			}
		}
	}
}
