#!/usr/bin/perl


#Divides the input file to separate data file
#one with categorical variables
#one with real variables
# this was used when we trained trees on categorical variables
# input file .xls format has since changes the columns numbers have to fixed accordingly


open (CAT, ">./cat-common.dat");
open (REAL, ">./real-common.dat");


open( HANDLE1 , "./finaldata.csv");

print "opened\n";
@catcolumns = (8,10,12,14,18,19,28,35,38,39,40,42,43,44,45,46,47,48,49,50,51,52,53,55,56,57,58,59,60,61,106,108,109,110,111,112,113); #categorical features
@realcolumns = (5,7,9,13,17,20,24,27,37); #real features

while ($line = <HANDLE1>)
{
	
	#print $line;
	@names = split(/\:/,$line);
	

	print REAL "$names[0]";	

	
	$val=1;
	foreach $col (@realcolumns)
	{
		print REAL " $val\:$names[$col-1]";
		$val=$val+1;
	}
	print REAL "\n";

	print CAT "$names[0]";
	foreach $col (@catcolumns)
	{
		print CAT ",$names[$col-1]";
	}
	
}
print "finished\n";						
