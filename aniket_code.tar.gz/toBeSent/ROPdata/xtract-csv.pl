#!/usr/bin/perl
#
#This file opens the finaldata.csv file and xtracts the requires fields into the final.dat file
#final.dat is in the format accepted by libsvm

open (INF, ">./final.dat");

open( HANDLE1 , "./finaldata.csv");

print "opened";
@columns = (5,6,8,9,10,12,13,14,17,18,19,20,24,27,28,35,37,38,39,40,42,43,44,45,46,47,48,49,50,51,52,53,55,56,57,58,59,60,61,106,108,109,110,111,112,113); #required fields in the csv file
$line = <HANDLE>;
while ($line = <HANDLE1>)
{

	#print $line;
	@names = split(/\:/,$line);

	#was added for the 2 class case
	#		if($names[0] == 2)
	#		{
	#			$names[0] = 1;
	#		}

	print INF "$names[0]";	

	$val=1;
	foreach $col (@columns)
	{
		print INF " $val\:$names[$col-1]";
		$val=$val+1;
	}

}
print "finished";						
